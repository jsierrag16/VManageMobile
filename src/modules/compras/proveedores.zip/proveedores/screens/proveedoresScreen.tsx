import axios from "axios";
import { Ionicons } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import AppCard from "@/components/ui/AppCard";
import { colors } from "@/core/theme/colors";
import { typography } from "@/core/theme/typography";
import ProveedorCard from "../components/proveedorCard";
import { getProveedores } from "../services/proveedores.service";
import type {
  ProveedorEstadoFilter,
  ProveedorItem,
} from "../types/proveedores.types";

const FILTERS: Array<{ label: string; value: ProveedorEstadoFilter }> = [
  { label: "Todos", value: "all" },
  { label: "Activos", value: "Activo" },
  { label: "Inactivos", value: "Inactivo" },
];

function normalizeText(value?: string | null) {
  return (value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

function normalizeEstado(value?: string | null) {
  const normalized = normalizeText(value);

  if (["activo", "true", "1"].includes(normalized)) return "Activo";
  return "Inactivo";
}

function getErrorMessage(error: unknown) {
  if (axios.isAxiosError(error)) {
    const message =
      error.response?.data?.message ??
      error.response?.data?.error ??
      error.message;

    if (Array.isArray(message)) return message.join(", ");
    if (typeof message === "string" && message.trim()) return message.trim();

    return "Error de conexión con la API";
  }

  if (error instanceof Error && error.message.trim()) {
    return error.message.trim();
  }

  return "Revisa la conexión o intenta nuevamente.";
}

export default function ProveedoresScreen() {
  const [search, setSearch] = useState("");
  const [estadoFilter, setEstadoFilter] =
    useState<ProveedorEstadoFilter>("all");

  const query = useQuery({
    queryKey: ["proveedores-mobile", estadoFilter],
    queryFn: () =>
      getProveedores({
        page: 1,
        limit: 1000,
        estado:
          estadoFilter === "all"
            ? undefined
            : estadoFilter === "Activo"
            ? "true"
            : "false",
      }),
    retry: 0,
    staleTime: 30000,
  });

  const filteredData = useMemo(() => {
    const data = query.data ?? [];
    const term = normalizeText(search);

    return data.filter((proveedor: ProveedorItem) => {
      const bucket = [
        proveedor.codigo,
        proveedor.numeroDocumento,
        proveedor.nombre,
        proveedor.email,
        proveedor.telefono,
        proveedor.contacto,
        proveedor.tipoDocumento,
        proveedor.tipoProveedor,
        proveedor.ciudad,
        proveedor.departamento,
        proveedor.estado,
      ]
        .map((value) => normalizeText(value))
        .join(" ");

      if (!term) return true;
      return bucket.includes(term);
    });
  }, [query.data, search]);

  const totalActivos = useMemo(() => {
    const data = query.data ?? [];
    return data.filter((item) => normalizeEstado(item.estado) === "Activo")
      .length;
  }, [query.data]);

  const totalInactivos = useMemo(() => {
    const data = query.data ?? [];
    return data.filter((item) => normalizeEstado(item.estado) === "Inactivo")
      .length;
  }, [query.data]);

  if (query.isLoading) {
    return (
      <View style={styles.centerState}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.stateText}>Cargando proveedores...</Text>
      </View>
    );
  }

  if (query.isError) {
    return (
      <AppCard>
        <Text style={styles.errorTitle}>No fue posible cargar proveedores</Text>
        <Text style={styles.errorText}>{getErrorMessage(query.error)}</Text>
      </AppCard>
    );
  }

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={styles.contentContainer}
      refreshControl={
        <RefreshControl
          refreshing={query.isRefetching}
          onRefresh={query.refetch}
          tintColor={colors.primary}
        />
      }
    >
      <View style={styles.header}>
        <Text style={styles.title}>Proveedores</Text>
        <Text style={styles.subtitle}>
          Consulta y visualiza la información de tus proveedores
        </Text>
      </View>

      <View style={styles.searchWrap}>
        <Ionicons
          name="search-outline"
          size={20}
          color={colors.textMuted}
          style={styles.searchIcon}
        />
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar proveedores..."
          placeholderTextColor={colors.textMuted}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filtersRow}
      >
        {FILTERS.map((filter) => {
          const active = estadoFilter === filter.value;

          return (
            <Pressable
              key={filter.value}
              onPress={() => setEstadoFilter(filter.value)}
              style={[styles.filterChip, active && styles.filterChipActive]}
            >
              <Text
                style={[
                  styles.filterChipText,
                  active && styles.filterChipTextActive,
                ]}
              >
                {filter.label}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <View style={styles.summaryRow}>
        <AppCard style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Proveedores visibles</Text>
          <Text style={styles.summaryValue}>{filteredData.length}</Text>
        </AppCard>

        <AppCard style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Activos</Text>
          <Text style={styles.summaryValue}>{totalActivos}</Text>
        </AppCard>

        <AppCard style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Inactivos</Text>
          <Text style={styles.summaryValue}>{totalInactivos}</Text>
        </AppCard>
      </View>

      <View style={styles.listSection}>
        {filteredData.length === 0 ? (
          <AppCard>
            <Text style={styles.emptyTitle}>Sin resultados</Text>
            <Text style={styles.emptyText}>
              No encontramos proveedores para ese criterio de búsqueda.
            </Text>
          </AppCard>
        ) : (
          filteredData.map((proveedor) => (
            <ProveedorCard key={proveedor.id} proveedor={proveedor} />
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  contentContainer: {
    paddingBottom: 24,
  },
  centerState: {
    paddingVertical: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  stateText: {
    marginTop: 12,
    color: colors.textSecondary,
    fontSize: 14,
    fontFamily: typography.fontFamily.medium,
  },
  header: {
    marginBottom: 16,
  },
  title: {
    color: colors.textPrimary,
    fontSize: 28,
    fontFamily: typography.fontFamily.extrabold,
    marginBottom: 8,
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 14,
    fontFamily: typography.fontFamily.medium,
    marginBottom: 12,
  },
  searchWrap: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 18,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    marginBottom: 14,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    color: colors.textPrimary,
    fontSize: 15,
    fontFamily: typography.fontFamily.medium,
    paddingVertical: 14,
  },
  filtersRow: {
    gap: 10,
    marginBottom: 14,
    paddingRight: 6,
  },
  filterChip: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  filterChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  filterChipText: {
    color: colors.textSecondary,
    fontSize: 13,
    fontFamily: typography.fontFamily.bold,
  },
  filterChipTextActive: {
    color: "#FFFFFF",
  },
  summaryRow: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 14,
  },
  summaryCard: {
    flex: 1,
  },
  summaryLabel: {
    color: colors.textMuted,
    fontSize: 12,
    fontFamily: typography.fontFamily.medium,
    marginBottom: 6,
  },
  summaryValue: {
    color: colors.textPrimary,
    fontSize: 24,
    fontFamily: typography.fontFamily.extrabold,
  },
  listSection: {
    marginTop: 4,
  },
  errorTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontFamily: typography.fontFamily.extrabold,
    marginBottom: 8,
  },
  errorText: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 22,
    fontFamily: typography.fontFamily.regular,
  },
  emptyTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontFamily: typography.fontFamily.extrabold,
    marginBottom: 8,
  },
  emptyText: {
    color: colors.textSecondary,
    fontSize: 14,
    lineHeight: 22,
    fontFamily: typography.fontFamily.regular,
  },
});
