import type { AxiosRequestConfig } from "axios";
import { http } from "@/core/api/http";
import {
  mapCatalogOption,
  mapMunicipioOption,
  mapProveedor,
  type CatalogOption,
  type MunicipioOption,
  type ProveedorItem,
} from "../types/proveedores.types";

export type { CatalogOption, MunicipioOption, ProveedorItem };

export type SaveProveedorPayload = {
  codigo_proveedor?: string;
  num_documento: string;
  nombre_empresa: string;
  email?: string;
  telefono?: string;
  direccion?: string;
  nombre_contacto?: string;
  id_tipo_proveedor: number;
  id_tipo_doc: number;
  id_municipio: number;
  estado?: boolean;
};

export type GetProveedoresParams = {
  page?: number;
  limit?: number;
  q?: string;
  estado?: "true" | "false";
  id_tipo_proveedor?: number;
  id_tipo_doc?: number;
  id_municipio?: number;
};

type RequestCandidate = {
  url: string;
  config?: AxiosRequestConfig;
};

const DEFAULT_LIMIT = 1000;

const cleanParams = (params?: Record<string, unknown>) => {
  return Object.fromEntries(
    Object.entries(params ?? {}).filter(
      ([, value]) => value !== undefined && value !== null && value !== ""
    )
  );
};

const unwrapResponse = (raw: any) => {
  if (raw == null) return raw;

  if (Array.isArray(raw)) return raw;

  if (typeof raw !== "object") return raw;

  if ("data" in raw && raw.data != null) return raw.data;
  if ("payload" in raw && raw.payload != null) return raw.payload;
  if ("result" in raw && raw.result != null) return raw.result;

  return raw;
};

const extractArray = <T = any>(raw: any): T[] => {
  const source = unwrapResponse(raw);

  if (Array.isArray(source)) return source;
  if (Array.isArray(source?.data)) return source.data;
  if (Array.isArray(source?.items)) return source.items;
  if (Array.isArray(source?.results)) return source.results;
  if (Array.isArray(source?.rows)) return source.rows;

  return [];
};

const getRequestFirstSuccess = async <T = any>(
  candidates: RequestCandidate[]
): Promise<T> => {
  let lastError: unknown;

  for (const candidate of candidates) {
    try {
      const response = await http.get<T>(candidate.url, candidate.config);
      return response.data;
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError;
};

const sortOptions = <T extends { label: string }>(items: T[]) =>
  [...items].sort((a, b) =>
    a.label.localeCompare(b.label, "es", { sensitivity: "base" })
  );

export const getProveedores = async (
  params: GetProveedoresParams = {}
): Promise<ProveedorItem[]> => {
  const raw = await getRequestFirstSuccess<any>([
    {
      url: "/proveedor",
      config: {
        params: cleanParams({
          page: params.page ?? 1,
          limit: params.limit ?? DEFAULT_LIMIT,
          q: params.q,
          estado: params.estado,
          id_tipo_proveedor: params.id_tipo_proveedor,
          id_tipo_doc: params.id_tipo_doc,
          id_municipio: params.id_municipio,
          includeRefs: "true",
        }),
      },
    },
    {
      url: "/proveedor",
      config: {
        params: cleanParams({
          page: params.page ?? 1,
          limit: params.limit ?? DEFAULT_LIMIT,
          q: params.q,
          estado: params.estado,
          id_tipo_proveedor: params.id_tipo_proveedor,
          id_tipo_doc: params.id_tipo_doc,
          id_municipio: params.id_municipio,
        }),
      },
    },
  ]);

  return extractArray(raw).map(mapProveedor);
};

export const getProveedorById = async (id: number): Promise<ProveedorItem> => {
  const raw = await getRequestFirstSuccess<any>([
    {
      url: `/proveedor/${id}`,
      config: {
        params: { includeRefs: "true" },
      },
    },
    {
      url: `/proveedor/${id}`,
    },
  ]);

  return mapProveedor(unwrapResponse(raw));
};

export const createProveedor = async (
  payload: SaveProveedorPayload
): Promise<ProveedorItem> => {
  const response = await http.post("/proveedor", payload);
  return mapProveedor(unwrapResponse(response.data));
};

export const updateProveedor = async (
  id: number,
  payload: SaveProveedorPayload
): Promise<ProveedorItem> => {
  const response = await http.patch(`/proveedor/${id}`, payload);
  return mapProveedor(unwrapResponse(response.data));
};

export const disableProveedor = async (id: number): Promise<ProveedorItem> => {
  const response = await http.delete(`/proveedor/${id}`);
  return mapProveedor(unwrapResponse(response.data));
};

export const enableProveedor = async (id: number): Promise<ProveedorItem> => {
  const response = await http.patch(`/proveedor/${id}/enable`);
  return mapProveedor(unwrapResponse(response.data));
};

export const getTiposDocumentoOptions = async (): Promise<CatalogOption[]> => {
  const raw = await getRequestFirstSuccess<any>([
    { url: "/tipo-documento" },
    { url: "/tipo_documento" },
    { url: "/tipos-documento" },
    { url: "/tipos-documentos" },
    { url: "/tipo-documentos" },
  ]);

  const items = extractArray(raw)
    .map((item) =>
      mapCatalogOption(
        item,
        ["id_tipo_doc", "id"],
        ["nombre_doc", "nombre", "label"]
      )
    )
    .filter((item) => item.value && item.label);

  return sortOptions(items);
};

export const getTiposProveedorOptions = async (): Promise<CatalogOption[]> => {
  const raw = await getRequestFirstSuccess<any>([
    { url: "/tipo-proveedor" },
    { url: "/tipo_proveedor" },
  ]);

  const items = extractArray(raw)
    .map((item: any) => ({
      value: String(item?.id_tipo_proveedor ?? item?.id ?? ""),
      label: String(
        item?.nombre_tipo_proveedor ?? item?.nombre ?? item?.label ?? ""
      ).trim(),
    }))
    .filter((item: CatalogOption) => item.value && item.label);

  return sortOptions(items);
};

export const getMunicipiosOptions = async (): Promise<MunicipioOption[]> => {
  const raw = await getRequestFirstSuccess<any>([
    {
      url: "/municipios",
      config: {
        params: cleanParams({
          page: 1,
          limit: 5000,
          includeRefs: "true",
        }),
      },
    },
    {
      url: "/municipios",
      config: {
        params: cleanParams({
          page: 1,
          limit: 5000,
        }),
      },
    },
    { url: "/municipios" },
  ]);

  const items = extractArray(raw)
    .map(mapMunicipioOption)
    .filter((item) => item.value && item.nombre);

  return sortOptions(items);
};
